let userscore=0;
let compscore=0; 

const choices=document.querySelectorAll(".choice");
const msg=document.querySelector("#msg");
const userscorepara=document.querySelector("#user-score");
const compscorepara=document.querySelector("#comp-score");

const genCompChoice=()=>{
    const options =["rock","parer","sissors"];
    const randIdx =Math.floor(Math.random()*3);
    return options[randIdx];
};
const drawGame=()=>{
    msg.innerText="Game was draw. play again";
    msg.style.background="black";
};
const showWinner=(userWin,userChoice,CompChoice)=>{
    if(userWin){
        userscore++;
        userscorepara.innerText=userscore;
        msg.innerText=`You win! ${userChoice} beats ${CompChoice}`;
        msg.style.background="green";
    }else{
        compscore++;
        compscorepara.innerText=compscore;
        msg.innerText=`You loss. ${CompChoice} beats ${userChoice}`;
        msg.style.background="red";
    }
}


const playGame =(userChoice)=>{
const CompChoice =genCompChoice();



if(userChoice === CompChoice){
 drawGame();
}else{
    let userWin =true;
    if(userChoice === "rock"){
      userWin= CompChoice==="paper"? false:true;
    }else if(userChoice==="paper"){
       userWin= CompChoice==="scissors"? false : true;

    }else{
       userWin= CompChoice==="rock"?false:true;
    }
    showWinner(userWin,userChoice,CompChoice);
}
};

choices.forEach((choice) => {
    console.log(choice);
    choice.addEventListener("click",()=>{
        const userChoice = choice.getAttribute("id");
        console.log("choice was clicked",userChoice);
        playGame(userChoice);

    });
});